interface IComponent extends IDestroyable {
}
