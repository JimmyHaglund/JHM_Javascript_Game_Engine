declare let onMouseDown: Action;
declare let onMouseUp: Action;
