interface IDestroyable {
    destroy(): void;
    onDestroy: Action;
}
