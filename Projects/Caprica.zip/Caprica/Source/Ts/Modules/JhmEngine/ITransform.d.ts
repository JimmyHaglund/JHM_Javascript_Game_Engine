interface ITransform {
    x: number;
    y: number;
    worldX: number;
    worldY: number;
    rotation: number;
    parent: Transform;
}
