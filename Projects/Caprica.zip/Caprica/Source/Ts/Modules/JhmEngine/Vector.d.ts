declare let vector: {
    up: {
        x: number;
        y: number;
    };
    right: {
        x: number;
        y: number;
    };
    down: {
        x: number;
        y: number;
    };
    left: {
        x: number;
        y: number;
    };
    add: (a: {
        x: number;
        y: number;
    }, b: {
        x: number;
        y: number;
    }) => {
        x: number;
        y: number;
    };
};
