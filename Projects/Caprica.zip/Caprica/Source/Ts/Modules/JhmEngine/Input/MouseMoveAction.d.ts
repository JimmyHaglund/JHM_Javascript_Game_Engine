declare let onMouseMoved: Action;
