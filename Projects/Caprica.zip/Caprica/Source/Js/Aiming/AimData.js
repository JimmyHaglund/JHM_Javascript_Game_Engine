class AimData {
    constructor(startAngle, endAngle, durationInSeconds) {
        this.aimStartAngle = Math.PI;
        this.aimEndAngle = Math.PI * 0.33;
        this.aimSeconds = 1.0;
        this.aimStartAngle = startAngle;
        this.aimEndAngle = endAngle;
        this.aimSeconds = durationInSeconds;
    }
}
